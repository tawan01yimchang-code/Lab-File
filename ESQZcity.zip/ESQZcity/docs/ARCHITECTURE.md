# ES QZcity — Architecture Plan (v0.1)

เกมมือถือ Open World Action-Adventure สไตล์ GTA เป้าหมายความสมจริงระดับ AAA
โปรเจกต์ใน ZIP นี้คือ **โครงสถาปัตยกรรม + โค้ดเริ่มต้นที่รันได้จริง** (เมืองบล็อก 3D, วัน-คืน, สภาพอากาศ, เมนู, ตั้งค่า, เซฟ/คลาวด์)
ส่วน "โมเดลตัวละคร Ultra-realistic / ตึกจริง / ฟิสิกส์ทำลายได้" ต้องใส่แอสเซ็ตและเอนจินตามแผนด้านล่าง (ดูข้อ 10)

## 1) ภาพรวมเลเยอร์
```
UI (Jetpack Compose)  Title · CharacterSelect · Settings · HUD
        │
AppViewModel ── GameSettings (SharedPrefs/JSON) ── SaveManager ── CloudSync(Firestore)
        │                                              ▲
        │                                   GameEvent (Mission/Outfit/VehicleExit)
        ▼
Game Core  DayNightCycle · WeatherSystem · CityGen · (Missions · Traffic AI · NPC AI · Wanted)
        ▼
Renderer   GameSurfaceView → CityRenderer (OpenGL ES 3.0)  ⇒ อนาคต: Filament / Vulkan
```

## 2) โครงโฟลเดอร์
| พาธ | หน้าที่ |
|---|---|
| `auth/AuthManager.kt` | Google Sign-In (Credential Manager) → Firebase Auth |
| `data/Models.kt` | `GameCharacter` ×8, `GameSettings` (+ presets), `SaveData`, `GameEvent` |
| `data/SaveManager.kt` | Auto-Save + Cloud Sync (ข้อมูลที่ `updatedAt` ใหม่กว่าชนะ) |
| `game/WorldSystems.kt` | วัน-คืน 24 ชม., สภาพอากาศ (Clear/Rain/Fog), ผังเมือง procedural |
| `game/CityRenderer.kt` | เรนเดอร์เมือง, แสงตามเวลา, หมอก, ฝน, รถ/NPC ตาม density, จำกัด FPS |
| `game/GameSurfaceView.kt` | GLSurfaceView + กล้อง + Resolution Scaling |
| `ui/*` | TitleScreen, CharacterScreen, SettingsScreen, GameScreen (HUD/จอยสติ๊ก), Components |

## 3) Authentication & Cloud Save
- Google Sign-In → ได้ ID token → `FirebaseAuth.signInWithCredential` → `uid`
- Cloud: Firestore `saves/{uid}` เก็บ JSON เซฟทั้งก้อน; เครื่องเก็บสำเนาล่าสุดใน SharedPreferences เสมอ (เล่นออฟไลน์ได้)
- **Auto-Save triggers** (ผ่าน `SaveManager.onEvent`): `MissionCompleted`, `OutfitChanged`, `VehicleExited`
  (ระบบภารกิจ/ตู้เสื้อผ้า/ยานพาหนะต้องยิง event นี้; ใน HUD มีปุ่มทดสอบ 3 ปุ่ม)
- ตอนล็อกอิน: `sync()` เทียบ `updatedAt` local vs cloud → ใหม่กว่าชนะ แล้วอัปโหลดอีกฝั่ง
- แนะนำเพิ่ม: เก็บ 3 slot ย้อนหลัง, Firestore security rules `request.auth.uid == uid`

## 4) เมนูและเริ่มเกม
Title: เมือง 3D แบบไดนามิก (กล้องโคจร + วัน/คืน) เป็นฉากหลัง + การ์ดตัวละครที่เลือก + ปุ่ม Start / Load (ปิดถ้าไม่มีเซฟ) / Character Selection / Settings + ปุ่ม Google Sign-In

## 5) ตัวละคร 8 ตัว
ข้อมูลใน `Roster`: Rex Navarro, Mira Volkov, Dante Cruz, Jade Lin, Ozzy Brooks, Sasha Reed, Kenji Mori, Luna Okafor
แต่ละตัวมี Health/Armor/Stamina/Special Ability, ชุดเฉพาะตัว, รอยสัก, รอยแผล, สไตล์ผม

**Pipeline ความสมจริง (ต้องทำในฝั่ง Art):**
1. ปั้น/สแกนโมเดลสูง → retopo → LOD0 ≤ 60k tris, LOD1/2 สำหรับมือถือ
2. Texture PBR (albedo/normal/roughness/AO) 2K–4K แบบ KTX2/ASTC; รอยสัก+แผลเป็น = decal layer แยก (สลับได้ตามชุด)
3. ผิวหนัง: pre-integrated SSS; ตา: refractive shader
4. ผม: hair cards + strand-based สำหรับ Ultra; Hair Physics ด้วย Verlet chain/ Jolt soft body
5. Animation: mocap → retarget สกีลตัวเดียวร่วมกัน 8 ตัว, IK เท้า, ragdoll blend
6. Export เป็น glTF 2.0 / `.filament`

## 6) โลก (Mega Open World)
- ผังปัจจุบัน (procedural ใน `CityGen`): ใจกลางตึกระฟ้า (ring ≤3), ย่านการค้า (≤6), ชานเมือง, **สลัม** (ตะวันออกเฉียงใต้), **ท่าเรือ** (ทิศใต้ + ผืนน้ำ), **ทางด่วนยกระดับ** (เสา+แผ่นพื้น)
- แผนระดับ Mega: แบ่งโลกเป็น chunk 256 m, สตรีมด้วย background thread, HLOD/Imposter สำหรับตึกไกล, เก็บ chunk ลง Memory ไม่เกิน ~3×3 รอบผู้เล่น
- วัน-คืน: 1 วัน = 24 นาที (ปรับได้) — ดวงอาทิตย์/แสงส้ม/หน้าต่างสว่างกลางคืน
- สภาพอากาศ: Clear/Rain/Fog (หมอก exponential, ฝน line particles) → เพิ่ม: พื้นเปียก (roughness↓), ฟ้าผ่า, เสียงฝน
- **Ray Tracing**: โค้ดมีสวิตช์ (ตอนนี้ปรับโทนน้ำ) — ของจริงใช้ Vulkan RT (เฉพาะ GPU ที่รองรับ) หรือ SSR + planar reflection + cubemap probe เป็น fallback บนเครื่องทั่วไป
- **Destructible**: ใช้ Jolt/Bullet; ออบเจ็กต์ pre-fractured (ป้าย, รั้ว, กระจก, ลัง) + debris pool; ตึกใช้ damage-state แทนการแตกจริง

## 7) Settings → ระบบจริง
| หมวด | ตัวเลือก | การเชื่อมต่อ |
|---|---|---|
| Graphics | Preset Low/Medium/High/Ultra/Extreme | `GameSettings.withPreset()` ตั้งค่าย่อยทั้งชุด |
| | FPS 30/60/120 | จำกัดเฟรมใน `CityRenderer` |
| | Resolution Scaling | `holder.setFixedSize` |
| | Shadows | ใช้งานได้: Shadow Map + PCF (Low=ปิด, Medium=1024, High/Ultra=2048) |
| | Ray Tracing | RT-lite: เพิ่มการสะท้อนท้องฟ้าบนกระจก/น้ำ/พื้นเปียก (ไม่ใช่ Hardware RT) |
| | Anti-Aliasing / Motion Blur | เก็บค่าแล้ว — รอ post-process pipeline (ข้อ 10) |
| Audio | Master/Music/SFX/Voice, Radio, 3D Surround | เก็บค่าแล้ว — ต่อ `AudioEngine` (Oboe/ExoPlayer + Spatializer) |
| Controls | Layout, Button size, Sensitivity | HUD อ่านค่าจริง (Lefty สลับซ้าย-ขวา) |
| | Steering Tilt/Buttons/Wheel, Gamepad | เก็บค่าแล้ว — ต้องทำระบบรถ + `InputDevice`/`MotionEvent` |
| Gameplay | Traffic / NPC density | จำนวนรถ/คนที่เรนเดอร์ปรับตามค่า |
| | Subtitles, Mini-Map style | มินิแมป Round/Square/Off ใช้ได้; Subtitles รอระบบบทพูด |

## 8) ประสิทธิภาพมือถือ
Preset → ปรับ draw distance, shadow cascades, density, resolution scale; Thermal throttling → ลด preset อัตโนมัติ (`PowerManager.ThermalStatus`); ใช้ instancing + frustum/occlusion culling; texture ASTC; เป้า 60 FPS บน High

## 9) ตั้งค่า Google Sign-In / Firebase
1. สร้างโปรเจกต์ Firebase → เพิ่มแอป Android แพ็กเกจ `com.esqzcity.game` + SHA-1
2. เปิด Authentication → Google; เปิด Firestore
3. ดาวน์โหลด `google-services.json` วางที่ `app/`
4. ใส่ Web client ID ใน `res/values/strings.xml` (`web_client_id`)
5. ไม่มีไฟล์ = แอปยังรันได้ แต่ล็อกอิน/คลาวด์จะไม่ทำงาน (เซฟในเครื่องยังใช้ได้)

## 10) Roadmap
1. **M1 (ZIP นี้)**: เมนู/ตั้งค่า/เซฟ/คลาวด์/เมืองบล็อก/วัน-คืน/สภาพอากาศ
2. **M2**: ย้ายเรนเดอร์ไป Filament (PBR, shadow cascades, TAA, SSR) + โหลด glTF
3. **M3**: ฟิสิกส์ (Jolt) + ระบบรถ (Tilt/Buttons/Wheel) + ระบบทำลาย
4. **M4**: AI ผู้คน/จราจร, ภารกิจ, Wanted, ตู้เสื้อผ้า (ยิง GameEvent จริง)
5. **M5**: ตัวละคร 8 ตัวแบบ realistic + Hair/Skin shader + mocap
6. **M6**: Audio/Radio/Surround, Gamepad, Optimization, Thermal

## 11) ความสมจริงที่ทำแล้ว (v0.2) vs สิ่งที่ต้องมีทีม/แอสเซ็ต
**ทำแล้วด้วยโค้ดล้วน (`CityRenderer.kt`, `Looks.kt`):**
- ท้องฟ้า procedural: ไล่สีตามเวลา, ดวงอาทิตย์/พระจันทร์/ดาว, เมฆเคลื่อนที่, ฝน/หมอกเปลี่ยนโทนฟ้า
- แสง PBR-lite: hemisphere ambient, specular + Fresnel สะท้อนท้องฟ้า, tone mapping แบบ ACES + gamma
- เงา Shadow Map + PCF 3×3
- อาคาร: กระจกหน้าต่างสะท้อน + ไฟหน้าต่างติดสุ่มตอนกลางคืน; ถนนมีเส้นแบ่งเลน, ฝนตก = พื้นเปียกเงา; ผิวน้ำมีคลื่น
- รถ: ตัวถัง/กระจก/ไฟหน้า-ไฟท้าย (ติดตอนกลางคืน)
- ตัวละคร 8 แบบ (ผิว/ผม/ชุด/รอยสัก/แผลเป็น) มีข้อต่อ + แอนิเมชันเดิน + ผมหางม้า Verlet physics; ปุ่มเปลี่ยนชุดเปลี่ยนสีชุดจริง

**ยังไม่ใช่ AAA เพราะต้องมี (นอกเหนือจากโค้ด):**
1. โมเดล 3D/เท็กซ์เจอร์/แอนิเมชัน mocap ที่ศิลปินทำหรือซื้อ (ตัวละคร, ตึก, รถ, props)
2. เอนจินเต็มรูปแบบ (Unreal/Unity/Filament) + ฟิสิกส์ (Jolt/Bullet) + AI จราจร/ผู้คน + ระบบภารกิจ
3. เสียง/เพลง/บทพูดมืออาชีพ และงาน QA/optimize ข้ามอุปกรณ์
4. เวลาและทีมจำนวนมาก — เกม AAA จริงใช้หลายร้อยคนหลายปี

ลำดับถัดไปที่คุ้มสุด: Filament + glTF (ข้อ 10 M2) แล้วค่อยใส่โมเดล/เท็กซ์เจอร์จริงทีละชุด
