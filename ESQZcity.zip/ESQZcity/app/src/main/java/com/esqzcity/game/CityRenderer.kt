package com.esqzcity.game

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import com.esqzcity.data.GameSettings
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

/**
 * Renderer v0.2 (OpenGL ES 3.0)
 *  - ท้องฟ้า procedural: ไล่สีตามเวลา, ดวงอาทิตย์/พระจันทร์, ดาว, เมฆเคลื่อนที่
 *  - แสง PBR-lite: ambient แบบ hemisphere, specular + Fresnel สะท้อนท้องฟ้า, tone mapping (ACES) + gamma
 *  - เงา Directional (Shadow Map + PCF) ตามคุณภาพเงาที่ตั้งค่า
 *  - อาคาร: หน้าต่างกระจกสะท้อน / ไฟหน้าต่างตอนกลางคืน, ถนนมีเส้นแบ่งเลน, พื้นเปียกตอนฝนตก, ผิวน้ำเคลื่อนไหว
 *  - ตัวละคร: โมเดล procedural มีข้อต่อ + แอนิเมชันเดิน + ผมหางม้า Verlet physics + ชุด/รอยสัก/แผลเป็น
 *  - รถมีไฟหน้า/ไฟท้าย, NPC, ฝน
 * ยังไม่ใช่ AAA: ไม่มีโมเดล/เท็กซ์เจอร์จริง — ดู docs/ARCHITECTURE.md
 */
class CityRenderer(private val demo: Boolean, private val clock: DayNightCycle, private val weather: WeatherSystem) : GLSurfaceView.Renderer {
    @Volatile var settings = GameSettings()
    @Volatile var moveX = 0f
    @Volatile var moveF = 0f
    @Volatile var yaw = 0.6f
    @Volatile var pitch = 0.5f
    @Volatile var charId = 0
    @Volatile var outfit = 0
    @Volatile var px = 0f
    @Volatile var pz = 40f

    private val buildings = CityGen.generate()
    private val cube: FloatBuffer = buildCube()
    private val rainBuf: FloatBuffer = ByteBuffer.allocateDirect(RAIN * 6 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private var prog = 0; private var depthProg = 0; private var skyProg = 0
    private var uMvp = 0; private var uModel = 0; private var uLightVP = 0; private var uColor = 0; private var uEmis = 0
    private var uSun = 0; private var uSunCol = 0; private var uAmbSky = 0; private var uAmbGnd = 0; private var uFogCol = 0
    private var uFog = 0; private var uCam = 0; private var uShadowMap = 0; private var uShadowOn = 0; private var uShadowTexel = 0
    private var uMat = 0; private var uRough = 0; private var uWet = 0; private var uNight = 0; private var uRT = 0; private var uAxis = 0; private var uTime = 0
    private var uLMvp = 0
    private var sInvVP = 0; private var sCam = 0; private var sZen = 0; private var sHor = 0; private var sSunDir = 0; private var sSunC = 0
    private var sNight = 0; private var sCloud = 0; private var sTime = 0; private var sDark = 0

    private val proj = FloatArray(16); private val view = FloatArray(16); private val vp = FloatArray(16); private val invVp = FloatArray(16)
    private val lp = FloatArray(16); private val lv = FloatArray(16); private val lightVP = FloatArray(16)
    private val model = FloatArray(16); private val mvp = FloatArray(16); private val pm = FloatArray(16); private val tmp = FloatArray(16)
    private var w = 1; private var h = 1
    private var last = System.nanoTime(); private var time = 0f
    private var shadowFbo = 0; private var shadowTex = 0; private var shadowSize = 0
    private var shadowPass = false
    private var cr = 1f; private var cg = 1f; private var cb = 1f
    // สถานะตัวละคร
    private var heading = 0f; private var walkPhase = 0f; private var moveMag = 0f
    private val tp = FloatArray(12); private val tprev = FloatArray(12); private var tailInit = false
    private var wet = 0f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        prog = link(MAIN_VS, MAIN_FS); depthProg = link(DEPTH_VS, DEPTH_FS); skyProg = link(SKY_VS, SKY_FS)
        fun u(n: String) = GLES30.glGetUniformLocation(prog, n)
        uMvp = u("uMvp"); uModel = u("uModel"); uLightVP = u("uLightVP"); uColor = u("uColor"); uEmis = u("uEmis")
        uSun = u("uSun"); uSunCol = u("uSunCol"); uAmbSky = u("uAmbSky"); uAmbGnd = u("uAmbGnd"); uFogCol = u("uFogCol")
        uFog = u("uFog"); uCam = u("uCam"); uShadowMap = u("uShadowMap"); uShadowOn = u("uShadowOn"); uShadowTexel = u("uShadowTexel")
        uMat = u("uMat"); uRough = u("uRough"); uWet = u("uWet"); uNight = u("uNight"); uRT = u("uRT"); uAxis = u("uAxis"); uTime = u("uTime")
        uLMvp = GLES30.glGetUniformLocation(depthProg, "uLMvp")
        fun s(n: String) = GLES30.glGetUniformLocation(skyProg, n)
        sInvVP = s("uInvVP"); sCam = s("uCam"); sZen = s("uZen"); sHor = s("uHor"); sSunDir = s("uSunDir"); sSunC = s("uSunC")
        sNight = s("uNight"); sCloud = s("uCloud"); sTime = s("uTime"); sDark = s("uDark")
        shadowFbo = 0; shadowTex = 0; shadowSize = 0   // บริบท GL ใหม่
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        w = width; h = height
        GLES30.glViewport(0, 0, w, h)
        Matrix.perspectiveM(proj, 0, 60f, w.toFloat() / h, 0.5f, 1400f)
    }

    private fun shadowQuality(): Int = when (settings.shadows) { "Low" -> 0; "Medium" -> 1024; else -> 2048 }

    private fun ensureShadow(size: Int) {
        if (size == shadowSize) return
        if (shadowTex != 0) { GLES30.glDeleteTextures(1, intArrayOf(shadowTex), 0); GLES30.glDeleteFramebuffers(1, intArrayOf(shadowFbo), 0); shadowTex = 0; shadowFbo = 0 }
        shadowSize = size
        if (size == 0) return
        val t = IntArray(1); val f = IntArray(1)
        GLES30.glGenTextures(1, t, 0); GLES30.glGenFramebuffers(1, f, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0])
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_DEPTH_COMPONENT24, size, size, 0, GLES30.GL_DEPTH_COMPONENT, GLES30.GL_UNSIGNED_INT, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_MODE, GLES30.GL_COMPARE_REF_TO_TEXTURE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_FUNC, GLES30.GL_LEQUAL)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, f[0])
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_TEXTURE_2D, t[0], 0)
        GLES30.glDrawBuffers(1, intArrayOf(GLES30.GL_NONE), 0); GLES30.glReadBuffer(GLES30.GL_NONE)
        val ok = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) == GLES30.GL_FRAMEBUFFER_COMPLETE
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
        if (ok) { shadowTex = t[0]; shadowFbo = f[0] } else { Log.w("ESQZ", "shadow FBO incomplete -> shadows off"); shadowSize = 0 }
    }

    override fun onDrawFrame(gl: GL10?) {
        val t0 = System.nanoTime()
        val dt = ((t0 - last) / 1e9f).coerceAtMost(0.1f); last = t0; time += dt
        clock.update(dt)
        val s = settings
        wet += ((if (weather.raining) 1f else 0f) - wet) * min(1f, dt * 0.25f)

        // ผู้เล่น: เคลื่อนที่ + หันหน้า + จังหวะเดิน
        if (!demo) {
            val mx = -sin(yaw) * moveF + cos(yaw) * moveX
            val mz = -cos(yaw) * moveF - sin(yaw) * moveX
            moveMag = min(1f, hypot(moveX, moveF))
            val sp = 14f * dt
            px += mx * sp; pz += mz * sp
            if (moveMag > 0.05f) {
                val target = Math.toDegrees(atan2(mx, mz).toDouble()).toFloat()
                val diff = ((target - heading + 540f) % 360f) - 180f
                heading += diff * min(1f, dt * 10f)
                walkPhase += dt * (7f + 4f * moveMag)
            }
        }

        // แสง / ท้องฟ้า
        val day = clock.dayFactor; val night = clock.nightFactor; val dusk = clock.duskFactor; val dark = 1f - weather.darkness
        val a = ((clock.hour - 6f) / 12f * PI).toFloat()
        val sunV = norm(cos(a) * 0.4f, abs(sin(a)).coerceAtLeast(0.15f), 0.5f)
        var zr = mix(0.01f, 0.18f, day); var zg = mix(0.015f, 0.40f, day); var zb = mix(0.05f, 0.80f, day)
        var hr = mix(0.04f, 0.62f, day) + 0.55f * dusk; var hg = mix(0.06f, 0.78f, day) + 0.25f * dusk; var hb = mix(0.12f, 0.95f, day) - 0.2f * dusk
        if (weather.type != Weather.Clear) {
            val k = if (weather.type == Weather.Fog) 0.7f else 0.5f; val gray = 0.3f + 0.45f * day
            zr = mix(zr, gray, k); zg = mix(zg, gray, k); zb = mix(zb, gray * 1.02f, k)
            hr = mix(hr, gray * 1.05f, k); hg = mix(hg, gray * 1.07f, k); hb = mix(hb, gray * 1.1f, k)
        }
        zr *= dark; zg *= dark; zb *= dark; hr *= dark; hg *= dark; hb *= dark
        val cloud = when (weather.type) { Weather.Clear -> 0.5f; Weather.Rain -> 0.95f; Weather.Fog -> 0.8f }
        val sunR = 3.2f * day * dark + 2.4f * dusk * dark + 0.10f * night
        val sunG = 2.9f * day * dark + 1.1f * dusk * dark + 0.15f * night
        val sunB = 2.4f * day * dark + 0.4f * dusk * dark + 0.30f * night

        // กล้อง
        val ex: Float; val ey: Float; val ez: Float; val tx: Float; val ty: Float; val tz: Float
        if (demo) {
            val ang = time * 0.07f
            ex = cos(ang) * 190f; ey = 85f + sin(time * 0.2f) * 8f; ez = sin(ang) * 190f - 40f; tx = 0f; ty = 25f; tz = -30f
        } else {
            val dist = 7.5f
            ex = px + dist * cos(pitch) * sin(yaw); ey = 1.6f + dist * sin(pitch); ez = pz + dist * cos(pitch) * cos(yaw)
            tx = px; ty = 1.5f; tz = pz
        }
        Matrix.setLookAtM(view, 0, ex, ey, ez, tx, ty, tz, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        Matrix.invertM(invVp, 0, vp, 0)

        if (!demo) updateTail(dt)

        // ---------- Shadow pass ----------
        ensureShadow(shadowQuality())
        val shadowOn = shadowTex != 0
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
        if (shadowOn) {
            val ext = if (demo) 280f else 55f
            val cx = if (demo) 0f else px; val cz = if (demo) -30f else pz
            Matrix.orthoM(lp, 0, -ext, ext, -ext, ext, 10f, 520f)
            Matrix.setLookAtM(lv, 0, cx + sunV[0] * 250f, sunV[1] * 250f, cz + sunV[2] * 250f, cx, 0f, cz, 0f, 1f, 0f)
            Matrix.multiplyMM(lightVP, 0, lp, 0, lv, 0)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, shadowFbo)
            GLES30.glViewport(0, 0, shadowSize, shadowSize)
            GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT)
            GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glPolygonOffset(2f, 4f)
            GLES30.glUseProgram(depthProg)
            shadowPass = true; bindCube(); drawCasters(cx, cz, ext); shadowPass = false
            GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glViewport(0, 0, w, h)
        }

        // ---------- Main pass ----------
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        GLES30.glDisableVertexAttribArray(0); GLES30.glDisableVertexAttribArray(1)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glUseProgram(skyProg)
        GLES30.glUniformMatrix4fv(sInvVP, 1, false, invVp, 0)
        GLES30.glUniform3f(sCam, ex, ey, ez); GLES30.glUniform3f(sZen, zr, zg, zb); GLES30.glUniform3f(sHor, hr, hg, hb)
        GLES30.glUniform3f(sSunDir, sunV[0], sunV[1], sunV[2])
        GLES30.glUniform3f(sSunC, mix(0.25f, 1f, day), mix(0.3f, 0.9f, day), mix(0.5f, 0.7f, day))
        GLES30.glUniform1f(sNight, night); GLES30.glUniform1f(sCloud, cloud); GLES30.glUniform1f(sTime, time)
        GLES30.glUniform1f(sDark, if (weather.type == Weather.Rain) 0.45f else 1f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)

        GLES30.glUseProgram(prog)
        GLES30.glUniformMatrix4fv(uLightVP, 1, false, lightVP, 0)
        GLES30.glUniform3f(uSun, sunV[0], sunV[1], sunV[2])
        GLES30.glUniform3f(uSunCol, sunR, sunG, sunB)
        GLES30.glUniform3f(uAmbSky, mix(0.02f, 0.50f, day) * dark, mix(0.03f, 0.65f, day) * dark, mix(0.07f, 0.90f, day) * dark)
        GLES30.glUniform3f(uAmbGnd, mix(0.015f, 0.20f, day) * dark, mix(0.015f, 0.18f, day) * dark, mix(0.02f, 0.15f, day) * dark)
        GLES30.glUniform3f(uFogCol, hr, hg, hb)
        GLES30.glUniform1f(uFog, weather.fogDensity)
        GLES30.glUniform3f(uCam, ex, ey, ez)
        GLES30.glUniform1f(uWet, wet); GLES30.glUniform1f(uNight, night); GLES30.glUniform1f(uRT, if (s.rayTracing) 1f else 0f); GLES30.glUniform1f(uTime, time)
        GLES30.glUniform1f(uShadowOn, if (shadowOn) 1f else 0f)
        GLES30.glUniform1f(uShadowTexel, if (shadowOn) (if (s.shadows == "Ultra") 1.6f else 1f) / shadowSize else 0f)
        if (shadowOn) { GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, shadowTex); GLES30.glUniform1i(uShadowMap, 0) }
        else { GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0) }
        bindCube()
        emis(0f, 0f, 0f)
        drawScene(night, ex, ez)
        if (weather.raining) drawRain(ex, ez)

        // จำกัดเฟรมเรตตามการตั้งค่า (30/60/120)
        val target = 1_000_000_000L / s.fps
        val spent = System.nanoTime() - t0
        if (spent < target) runCatching { Thread.sleep((target - spent) / 1_000_000L) }
    }

    // ---------- Scene ----------
    private fun drawScene(night: Float, ex: Float, ez: Float) {
        mat(4f, 0.92f); box(0f, -0.5f, 0f, 700f, 1f, 700f, 0.16f, 0.20f, 0.15f)                // พื้น
        mat(3f, 0.04f); box(0f, 0.05f, -420f, 700f, 0.1f, 340f, 0.1f, 0.2f, 0.3f)               // ผืนน้ำท่าเรือ
        mat(2f, 0.85f)                                                                            // ถนน
        for (i in -CityGen.N - 1..CityGen.N) {
            val p = i * CityGen.PITCH + CityGen.PITCH / 2
            axis(0f); box(0f, 0.04f, p, 520f, 0.05f, 6f, 0.07f, 0.07f, 0.08f)
            axis(1f); box(p, 0.045f, 0f, 6f, 0.05f, 520f, 0.07f, 0.07f, 0.08f)
        }
        mat(1f, 0.55f)                                                                            // อาคาร
        for (b in buildings) {
            val dx = b.x - ex; val dz = b.z - ez
            if (dx * dx + dz * dz < 600f * 600f) box(b.x, 0f, b.z, b.w, b.h, b.d, b.r, b.g, b.b)
        }
        drawTraffic(night); drawNpcs()
        if (!demo) drawPlayer()
    }

    private fun drawCasters(cx: Float, cz: Float, ext: Float) {
        for (b in buildings) if (abs(b.x - cx) < ext + 15f && abs(b.z - cz) < ext + 15f) box(b.x, 0f, b.z, b.w, b.h, b.d, 0f, 0f, 0f)
        drawTraffic(0f); drawNpcs()
        if (!demo) drawPlayer()
    }

    private fun drawTraffic(night: Float) {
        val cars = (settings.traffic * 60).toInt()
        for (k in 0 until cars) {
            val road = (k * 7) % 22 - 11
            val dir = if (k % 2 == 0) 1f else -1f
            val lane = dir * 1.6f
            val pos = ((time * (8f + k % 5 * 3f) * dir + k * 53f) % 520f + 520f) % 520f - 260f
            val p = road * CityGen.PITCH + CityGen.PITCH / 2
            val alongX = k % 4 < 2
            Matrix.setIdentityM(pm, 0)
            if (alongX) { Matrix.translateM(pm, 0, pos, 0f, p + lane); if (dir < 0) Matrix.rotateM(pm, 0, 180f, 0f, 1f, 0f) }
            else { Matrix.translateM(pm, 0, p + lane, 0f, pos); Matrix.rotateM(pm, 0, if (dir > 0) -90f else 90f, 0f, 1f, 0f) }
            val col = floatArrayOf(0.25f + (k * 37 % 70) / 100f, 0.2f + (k * 17 % 60) / 100f, 0.2f + (k * 29 % 70) / 100f)
            mat(0f, 0.3f); part(pm, 0f, 0.3f, 0f, 0f, 0f, 0f, 0f, 4.2f, 0.6f, 1.9f, col)
            part(pm, 0f, 0.1f, 0f, 0f, 0f, 0f, 0f, 3.9f, 0.3f, 1.7f, DARK)
            mat(0f, 0.06f); part(pm, -0.2f, 0.9f, 0f, 0f, 0f, 0f, 0f, 2.2f, 0.55f, 1.75f, GLASS)
            if (!shadowPass && night > 0.15f) {
                mat(0f, 0.3f)
                emis(3f * night, 2.7f * night, 2.1f * night); part(pm, 2.1f, 0.5f, 0f, 0f, 0f, 0f, 0f, 0.1f, 0.18f, 1.5f, WHITE)
                emis(2.2f * night, 0.1f * night, 0.1f * night); part(pm, -2.1f, 0.5f, 0f, 0f, 0f, 0f, 0f, 0.1f, 0.18f, 1.5f, RED)
                emis(0f, 0f, 0f)
            }
        }
    }

    private fun drawNpcs() {
        val n = (settings.npc * 80).toInt()
        mat(0f, 0.7f)
        for (k in 0 until n) {
            val x = (k * 37 % 300) - 150f + sin(time * 0.5f + k) * 3f; val z = (k * 91 % 300) - 150f + cos(time * 0.4f + k) * 3f
            val r = 0.25f + (k * 13 % 70) / 100f; val g = 0.25f + (k * 29 % 60) / 100f; val bl = 0.25f + (k * 7 % 70) / 100f
            box(x, 0f, z, 0.45f, 1.35f, 0.3f, r, g, bl)
            box(x, 1.35f, z, 0.25f, 0.25f, 0.25f, 0.8f, 0.62f, 0.5f)
        }
    }

    private fun drawPlayer() {
        val l = Looks.all[charId.coerceIn(0, 7)]; val o = outfit.coerceIn(0, 3)
        val top = Looks.top(l, o); val bot = Looks.bottom(l, o)
        Matrix.setIdentityM(pm, 0); Matrix.translateM(pm, 0, px, 0f, pz); Matrix.rotateM(pm, 0, heading, 0f, 1f, 0f)
        val sw = sin(walkPhase) * 40f * moveMag
        mat(0f, 0.65f)
        part(pm, -0.14f, 0.9f, 0f, sw, 0f, -0.9f, 0f, 0.2f, 0.9f, 0.22f, bot)
        part(pm, 0.14f, 0.9f, 0f, -sw, 0f, -0.9f, 0f, 0.2f, 0.9f, 0.22f, bot)
        mat(0f, 0.35f)
        part(pm, -0.14f, 0.9f, 0f, sw, 0f, -0.9f, 0.05f, 0.22f, 0.12f, 0.32f, SHOE)
        part(pm, 0.14f, 0.9f, 0f, -sw, 0f, -0.9f, 0.05f, 0.22f, 0.12f, 0.32f, SHOE)
        mat(0f, 0.65f)
        part(pm, 0f, 0.9f, 0f, 0f, 0f, 0f, 0f, 0.55f, 0.75f, 0.3f, top)
        for (side in -1..1 step 2) {
            val sa = if (side < 0) -sw else sw
            part(pm, side * 0.37f, 1.6f, 0f, sa, 0f, -0.35f, 0f, 0.16f, 0.35f, 0.16f, top)
            mat(0f, 0.55f)
            part(pm, side * 0.37f, 1.6f, 0f, sa, 0f, -0.7f, 0f, 0.14f, 0.35f, 0.14f, l.skin)
            if (l.tattoo != null && side > 0) part(pm, 0.37f, 1.6f, 0f, sa, 0f, -0.62f, 0f, 0.15f, 0.2f, 0.15f, l.tattoo)
            mat(0f, 0.65f)
        }
        mat(0f, 0.5f)
        part(pm, 0f, 1.65f, 0f, 0f, 0f, 0f, 0f, 0.3f, 0.3f, 0.3f, l.skin)                    // หัว
        mat(0f, 0.75f)
        part(pm, 0f, 1.82f, 0f, 0f, 0f, 0f, 0f, 0.33f, 0.15f, 0.33f, l.hair)                  // ผมด้านบน
        part(pm, 0f, 1.68f, -0.1f, 0f, 0f, 0f, 0f, 0.33f, 0.24f, 0.12f, l.hair)               // ผมด้านหลัง
        mat(0f, 0.3f)
        part(pm, -0.07f, 1.76f, 0.152f, 0f, 0f, 0f, 0f, 0.05f, 0.04f, 0.02f, EYE)
        part(pm, 0.07f, 1.76f, 0.152f, 0f, 0f, 0f, 0f, 0.05f, 0.04f, 0.02f, EYE)
        if (l.scar) part(pm, 0.1f, 1.68f, 0.152f, 0f, 0f, 0f, 0f, 0.02f, 0.1f, 0.01f, SCAR)  // แผลเป็นที่แก้ม
        if (l.tail) { mat(0f, 0.75f); for (i in 0 until 4) box(tp[i * 3] - 0.045f, tp[i * 3 + 1] - 0.09f, tp[i * 3 + 2] - 0.045f, 0.09f, 0.18f, 0.09f, l.hair[0], l.hair[1], l.hair[2]) }
    }

    /** ผมหางม้า: Verlet chain 4 ข้อ ตามแรงเฉื่อย/แรงโน้มถ่วง */
    private fun updateTail(dt: Float) {
        val hr = Math.toRadians(heading.toDouble()).toFloat()
        val ax = px - sin(hr) * 0.17f; val ay = 1.82f; val az = pz - cos(hr) * 0.17f
        if (!tailInit) { for (i in 0 until 4) { tp[i * 3] = ax; tp[i * 3 + 1] = ay - i * 0.17f; tp[i * 3 + 2] = az; tprev[i * 3] = ax; tprev[i * 3 + 1] = ay - i * 0.17f; tprev[i * 3 + 2] = az }; tailInit = true }
        var qx = ax; var qy = ay; var qz = az
        for (i in 0 until 4) {
            val o = i * 3
            val vx = (tp[o] - tprev[o]) * 0.92f; val vy = (tp[o + 1] - tprev[o + 1]) * 0.92f; val vz = (tp[o + 2] - tprev[o + 2]) * 0.92f
            tprev[o] = tp[o]; tprev[o + 1] = tp[o + 1]; tprev[o + 2] = tp[o + 2]
            tp[o] += vx; tp[o + 1] += vy - 9.8f * dt * dt * 0.6f; tp[o + 2] += vz
            var dx = tp[o] - qx; var dy = tp[o + 1] - qy; var dz = tp[o + 2] - qz
            val len = sqrt(dx * dx + dy * dy + dz * dz) + 1e-5f
            tp[o] = qx + dx / len * 0.17f; tp[o + 1] = qy + dy / len * 0.17f; tp[o + 2] = qz + dz / len * 0.17f
            qx = tp[o]; qy = tp[o + 1]; qz = tp[o + 2]
        }
    }

    private fun drawRain(cx: Float, cz: Float) {
        rainBuf.clear()
        for (i in 0 until RAIN) {
            val x = cx + ((i * 37) % 120) - 60f; val z = cz + ((i * 91) % 120) - 60f
            val y = 60f - ((i * 13 + time * 45f) % 60f)
            rainBuf.put(x).put(y).put(z).put(x + 0.1f).put(y - 1.4f).put(z)
        }
        rainBuf.position(0)
        GLES30.glDisableVertexAttribArray(1); GLES30.glVertexAttrib3f(1, 0f, 1f, 0f)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 12, rainBuf)
        Matrix.setIdentityM(model, 0)
        GLES30.glUniformMatrix4fv(uMvp, 1, false, vp, 0); GLES30.glUniformMatrix4fv(uModel, 1, false, model, 0)
        mat(0f, 1f); GLES30.glUniform3f(uColor, 0.7f, 0.8f, 1f); emis(0.5f, 0.6f, 0.8f)
        GLES30.glDrawArrays(GLES30.GL_LINES, 0, RAIN * 2)
        emis(0f, 0f, 0f)
    }

    // ---------- Draw helpers ----------
    private fun bindCube() {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        GLES30.glEnableVertexAttribArray(0); GLES30.glEnableVertexAttribArray(1)
        cube.position(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, cube)
        cube.position(3); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, cube)
    }

    private fun mat(m: Float, r: Float) { if (!shadowPass) { GLES30.glUniform1f(uMat, m); GLES30.glUniform1f(uRough, r) } }
    private fun axis(a: Float) { if (!shadowPass) GLES30.glUniform1f(uAxis, a) }
    private fun emis(r: Float, g: Float, b: Float) { if (!shadowPass) GLES30.glUniform3f(uEmis, r, g, b) }

    private fun draw(m: FloatArray) {
        if (shadowPass) {
            Matrix.multiplyMM(mvp, 0, lightVP, 0, m, 0); GLES30.glUniformMatrix4fv(uLMvp, 1, false, mvp, 0)
        } else {
            Matrix.multiplyMM(mvp, 0, vp, 0, m, 0)
            GLES30.glUniformMatrix4fv(uMvp, 1, false, mvp, 0); GLES30.glUniformMatrix4fv(uModel, 1, false, m, 0)
            GLES30.glUniform3f(uColor, cr, cg, cb)
        }
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 36)
    }

    private fun box(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, r: Float, g: Float, b: Float) {
        cr = r; cg = g; cb = b
        Matrix.setIdentityM(model, 0); Matrix.translateM(model, 0, x, y, z); Matrix.scaleM(model, 0, sx, sy, sz)
        draw(model)
    }

    /** ชิ้นส่วนมีข้อต่อ: ย้ายไปที่จุดหมุน → หมุนรอบ X → เลื่อนออกจากจุดหมุน → สเกล */
    private fun part(base: FloatArray, tx: Float, ty: Float, tz: Float, rxDeg: Float, ox: Float, oy: Float, oz: Float,
                     sx: Float, sy: Float, sz: Float, c: FloatArray) {
        cr = c[0]; cg = c[1]; cb = c[2]
        System.arraycopy(base, 0, tmp, 0, 16)
        Matrix.translateM(tmp, 0, tx, ty, tz)
        if (rxDeg != 0f) Matrix.rotateM(tmp, 0, rxDeg, 1f, 0f, 0f)
        Matrix.translateM(tmp, 0, ox, oy, oz)
        Matrix.scaleM(tmp, 0, sx, sy, sz)
        draw(tmp)
    }

    private fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun norm(x: Float, y: Float, z: Float): FloatArray { val l = sqrt(x * x + y * y + z * z); return floatArrayOf(x / l, y / l, z / l) }

    private fun link(vs: String, fs: String): Int {
        fun sh(type: Int, src: String): Int {
            val id = GLES30.glCreateShader(type); GLES30.glShaderSource(id, src); GLES30.glCompileShader(id)
            val ok = IntArray(1); GLES30.glGetShaderiv(id, GLES30.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) Log.e("ESQZ", "shader error: " + GLES30.glGetShaderInfoLog(id))
            return id
        }
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, sh(GLES30.GL_VERTEX_SHADER, vs)); GLES30.glAttachShader(p, sh(GLES30.GL_FRAGMENT_SHADER, fs)); GLES30.glLinkProgram(p)
        return p
    }

    private fun buildCube(): FloatBuffer {
        val faces = arrayOf(
            floatArrayOf(0f, 0f, 1f, -.5f, 0f, .5f, .5f, 0f, .5f, .5f, 1f, .5f, -.5f, 1f, .5f),
            floatArrayOf(0f, 0f, -1f, .5f, 0f, -.5f, -.5f, 0f, -.5f, -.5f, 1f, -.5f, .5f, 1f, -.5f),
            floatArrayOf(1f, 0f, 0f, .5f, 0f, .5f, .5f, 0f, -.5f, .5f, 1f, -.5f, .5f, 1f, .5f),
            floatArrayOf(-1f, 0f, 0f, -.5f, 0f, -.5f, -.5f, 0f, .5f, -.5f, 1f, .5f, -.5f, 1f, -.5f),
            floatArrayOf(0f, 1f, 0f, -.5f, 1f, .5f, .5f, 1f, .5f, .5f, 1f, -.5f, -.5f, 1f, -.5f),
            floatArrayOf(0f, -1f, 0f, -.5f, 0f, -.5f, .5f, 0f, -.5f, .5f, 0f, .5f, -.5f, 0f, .5f)
        )
        val bb = ByteBuffer.allocateDirect(36 * 6 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (f in faces) for (idx in intArrayOf(0, 1, 2, 0, 2, 3)) {
            bb.put(f[3 + idx * 3]).put(f[4 + idx * 3]).put(f[5 + idx * 3]).put(f[0]).put(f[1]).put(f[2])
        }
        bb.position(0); return bb
    }

    companion object {
        const val RAIN = 500
        private val DARK = floatArrayOf(0.03f, 0.03f, 0.035f); private val GLASS = floatArrayOf(0.04f, 0.07f, 0.1f)
        private val WHITE = floatArrayOf(1f, 1f, 0.9f); private val RED = floatArrayOf(1f, 0.1f, 0.1f)
        private val SHOE = floatArrayOf(0.08f, 0.08f, 0.09f); private val EYE = floatArrayOf(0.05f, 0.04f, 0.04f); private val SCAR = floatArrayOf(0.75f, 0.45f, 0.45f)

        private const val MAIN_VS = """#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNor;
uniform mat4 uMvp, uModel, uLightVP;
out vec3 vN; out vec3 vW; out vec4 vL; out vec3 vLoc;
void main(){ vec4 w=uModel*vec4(aPos,1.0); vW=w.xyz; vN=mat3(uModel)*aNor; vL=uLightVP*w; vLoc=aPos; gl_Position=uMvp*vec4(aPos,1.0); }"""

        private const val MAIN_FS = """#version 300 es
precision highp float;
precision highp sampler2DShadow;
uniform vec3 uColor,uEmis,uSun,uSunCol,uAmbSky,uAmbGnd,uFogCol,uCam;
uniform float uFog,uMat,uRough,uWet,uNight,uRT,uAxis,uShadowOn,uShadowTexel,uTime;
uniform sampler2DShadow uShadowMap;
in vec3 vN; in vec3 vW; in vec4 vL; in vec3 vLoc;
out vec4 o;
float hh(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }
void main(){
  vec3 N=normalize(vN); vec3 V=normalize(uCam-vW);
  vec3 alb=pow(uColor,vec3(2.2)); float rough=uRough; vec3 emis=uEmis;
  if(uMat>0.5 && uMat<1.5){
    if(abs(N.y)<0.5){
      float u=abs(N.x)>0.5 ? vW.z : vW.x;
      vec2 g=vec2(u/3.2, vW.y/3.6); vec2 id=floor(g); vec2 f=fract(g);
      float win=step(0.18,f.x)*step(f.x,0.82)*step(0.2,f.y)*step(f.y,0.8)*step(3.5,vW.y);
      float lit=step(0.6,hh(id+floor(vW.xz*0.05)))*uNight;
      alb=mix(alb,vec3(0.012,0.03,0.055),win); rough=mix(rough,0.07,win);
      emis+=win*lit*vec3(1.0,0.75,0.42)*1.2;
    }
  } else if(uMat>1.5 && uMat<2.5){
    alb=vec3(0.03)*(0.8+0.4*hh(floor(vW.xz*2.0))); rough=0.85;
    float across=(uAxis<0.5 ? vLoc.z : vLoc.x)*6.0; float along=(uAxis<0.5 ? vW.x : vW.z);
    float cl=step(abs(across),0.12)*step(fract(along/6.0),0.5);
    float edge=step(abs(abs(across)-2.6),0.07);
    alb=mix(alb,vec3(0.5,0.4,0.08),cl); alb=mix(alb,vec3(0.35),edge);
    rough=mix(rough,0.15,uWet); alb*=1.0-0.45*uWet;
  } else if(uMat>2.5 && uMat<3.5){
    N=normalize(vec3(sin(vW.x*0.35+uTime*1.1)*0.06,1.0,cos(vW.z*0.3+uTime*0.9)*0.06));
    alb=pow(vec3(0.05,0.15,0.22),vec3(2.2)); rough=0.04;
  } else if(uMat>3.5){
    alb*=0.85+0.3*hh(floor(vW.xz*0.7));
    rough=mix(rough,0.2,uWet); alb*=1.0-0.4*uWet;
  }
  float sh=1.0;
  if(uShadowOn>0.5){
    vec3 p=vL.xyz/vL.w*0.5+0.5; sh=0.0;
    for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) sh+=texture(uShadowMap,vec3(p.xy+vec2(float(x),float(y))*uShadowTexel,p.z-0.0008));
    sh/=9.0;
    if(p.x<0.0||p.x>1.0||p.y<0.0||p.y>1.0||p.z>1.0) sh=1.0;
  }
  vec3 L=normalize(uSun); float ndl=max(dot(N,L),0.0);
  vec3 H=normalize(L+V); float shin=mix(6.0,220.0,pow(1.0-rough,2.0));
  float spec=pow(max(dot(N,H),0.0),shin)*(1.0-rough)*ndl*(shin+8.0)/25.0;
  float fres=0.04+0.96*pow(1.0-max(dot(N,V),0.0),5.0);
  vec3 R=reflect(-V,N);
  vec3 skyR=pow(mix(uFogCol,uAmbSky*1.4,clamp(R.y,0.0,1.0)),vec3(2.2));
  float reflK=(1.0-rough)*fres*(1.0+uRT*0.9);
  vec3 amb=mix(uAmbGnd,uAmbSky,N.y*0.5+0.5)*alb;
  vec3 c=amb+alb*uSunCol*ndl*sh+uSunCol*spec*sh+skyR*reflK+emis;
  c=(c*(2.51*c+0.03))/(c*(2.43*c+0.59)+0.14);
  c=pow(clamp(c,0.0,1.0),vec3(1.0/2.2));
  float fg=1.0-exp(-distance(vW,uCam)*uFog);
  o=vec4(mix(c,uFogCol,clamp(fg,0.0,1.0)),1.0);
}"""

        private const val DEPTH_VS = """#version 300 es
layout(location=0) in vec3 aPos; uniform mat4 uLMvp;
void main(){ gl_Position=uLMvp*vec4(aPos,1.0); }"""
        private const val DEPTH_FS = """#version 300 es
precision mediump float; out vec4 o; void main(){ o=vec4(1.0); }"""

        private const val SKY_VS = """#version 300 es
out vec2 ndc;
void main(){ vec2 p=vec2(float((gl_VertexID<<1)&2), float(gl_VertexID&2)); ndc=p*2.0-1.0; gl_Position=vec4(ndc,1.0,1.0); }"""

        private const val SKY_FS = """#version 300 es
precision highp float;
uniform mat4 uInvVP; uniform vec3 uCam,uZen,uHor,uSunDir,uSunC; uniform float uNight,uCloud,uTime,uDark;
in vec2 ndc; out vec4 o;
float h2(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float n2(vec2 p){ vec2 i=floor(p),f=fract(p); f=f*f*(3.0-2.0*f);
  return mix(mix(h2(i),h2(i+vec2(1.0,0.0)),f.x),mix(h2(i+vec2(0.0,1.0)),h2(i+vec2(1.0,1.0)),f.x),f.y); }
float fbm(vec2 p){ float a=0.5,s=0.0; for(int i=0;i<4;i++){ s+=a*n2(p); p*=2.03; a*=0.5; } return s; }
void main(){
  vec4 w=uInvVP*vec4(ndc,1.0,1.0); vec3 d=normalize(w.xyz/w.w-uCam);
  float h=clamp(d.y,0.0,1.0);
  vec3 col=mix(uHor,uZen,pow(h,0.45));
  float sd=max(dot(d,normalize(uSunDir)),0.0);
  col+=uSunC*(pow(sd,1200.0)*4.0+pow(sd,10.0)*0.18);
  if(d.y>0.0){ float st=step(0.997,h2(floor(d.xz/(d.y+0.3)*140.0)))*uNight; col+=vec3(st); }
  if(d.y>0.015){
    vec2 p=d.xz/(d.y+0.12)*1.3+vec2(uTime*0.012,uTime*0.004);
    float c=smoothstep(1.0-uCloud,1.0,fbm(p))*smoothstep(0.015,0.2,d.y);
    vec3 cc=mix(uHor,vec3(1.0),0.55)*uDark*(1.0-0.85*uNight);
    col=mix(col,cc,c*0.85);
  }
  o=vec4(col,1.0);
}"""
    }
}
