package com.esqzcity.ui

import android.app.Activity
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.esqzcity.game.GameSurfaceView

/** มุมมอง 3D (OpenGL ES) ฝังใน Compose */
@Composable
fun GameSurface(vm: AppViewModel, demo: Boolean, modifier: Modifier = Modifier, onReady: (GameSurfaceView) -> Unit = {}) {
    val settings by vm.settings.collectAsState()
    val owner = LocalLifecycleOwner.current
    var view by remember { mutableStateOf<GameSurfaceView?>(null) }
    DisposableEffect(owner, view) {
        val o = LifecycleEventObserver { _, e -> when (e) { Lifecycle.Event.ON_PAUSE -> view?.onPause(); Lifecycle.Event.ON_RESUME -> view?.onResume(); else -> {} } }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    AndroidView(
        modifier = modifier,
        factory = { c -> GameSurfaceView(c, demo, vm.clock, vm.weather).also { view = it; onReady(it) } },
        update = { it.sensitivity = settings.sensitivity; it.applySettings(settings) }
    )
}

@Composable
fun ChoiceRow(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { FilterChip(selected = it == selected, onClick = { onSelect(it) }, label = { Text(it) }) }
        }
    }
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float> = 0f..1f, fmt: (Float) -> String = { "${(it * 100).toInt()}%" }, onChange: (Float) -> Unit) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, style = MaterialTheme.typography.labelLarge); Text(fmt(value)) }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.labelLarge); Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun StatBar(label: String, value: Int, max: Int, color: androidx.compose.ui.graphics.Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Text(label, Modifier.width(70.dp), style = MaterialTheme.typography.labelSmall)
        LinearProgressIndicator(progress = { value / max.toFloat() }, color = color, modifier = Modifier.width(130.dp).height(6.dp))
        Text("  $value", style = MaterialTheme.typography.labelSmall)
    }
}
