package com.esqzcity.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.esqzcity.data.GameEvent
import com.esqzcity.data.Roster
import com.esqzcity.game.GameSurfaceView
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun GameScreen(vm: AppViewModel, onExit: () -> Unit) {
    val save by vm.saves.state.collectAsState()
    val s by vm.settings.collectAsState()
    val lastSaved by vm.saves.lastSaved.collectAsState()
    val ch = Roster.all[save.characterId.coerceIn(0, 7)]
    var gl by remember { mutableStateOf<GameSurfaceView?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }
    var abilityReady by remember { mutableStateOf(true) }
    var wTick by remember { mutableIntStateOf(0) }
    val outfits = listOf("Default", "Street", "Formal", "Tactical")

    LaunchedEffect(lastSaved) { if (lastSaved > 0) { toast = "Auto-saved ✓"; delay(1800); toast = null } }
    LaunchedEffect(abilityReady) { if (!abilityReady) { delay(8000); abilityReady = true } }
    LaunchedEffect(gl, save.outfit) { gl?.renderer?.outfit = com.esqzcity.game.Looks.outfits.indexOf(save.outfit).coerceAtLeast(0) }
    DisposableEffect(gl) { gl?.renderer?.charId = ch.id; onDispose { vm.saves.update { it.copy(x = gl?.renderer?.px ?: 0f, z = gl?.renderer?.pz ?: 0f, hour = vm.clock.hour, weather = vm.weather.type.name) } } }

    val k = s.buttonSize
    val lefty = s.layout == "Lefty"
    Box(Modifier.fillMaxSize()) {
        GameSurface(vm, demo = false, modifier = Modifier.fillMaxSize()) { it.renderer.charId = ch.id; it.renderer.outfit = com.esqzcity.game.Looks.outfits.indexOf(save.outfit).coerceAtLeast(0); gl = it }
        // บนซ้าย: สถานะตัวละคร
        Column(Modifier.align(Alignment.TopStart).padding(14.dp).background(Color(0x99000000), RoundedCornerShape(10.dp)).padding(10.dp)) {
            Text(ch.name, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 14.sp)
            StatBar("Health", ch.health, 120, Color(0xFFE53935)); StatBar("Armor", ch.armor, 100, Color(0xFF42A5F5)); StatBar("Stamina", ch.stamina, 100, Color(0xFF66BB6A))
            Text("Mission #${save.missionIndex + 1}   $${save.money}", fontSize = 11.sp)
        }
        // บนกลาง: เวลา/สภาพอากาศ/Auto-save
        Row(Modifier.align(Alignment.TopCenter).padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            val tick = wTick
            AssistChip(onClick = { vm.weather.next(); wTick++ }, label = { Text("${vm.clock.label} • ${vm.weather.type}") })
            AssistChip(onClick = { vm.clock.hour = (vm.clock.hour + 4f) % 24f; wTick++ }, label = { Text("+4h") })
            toast?.let { Text(it, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp) }
        }
        // บนขวา: มินิแมป + ปุ่มหยุด
        Column(Modifier.align(Alignment.TopEnd).padding(14.dp), horizontalAlignment = Alignment.End) {
            TextButton(onClick = onExit) { Text("Pause ⏸") }
            if (s.miniMap != "Off") Canvas(Modifier.size(96.dp).clip(if (s.miniMap == "Round") CircleShape else RoundedCornerShape(8.dp)).background(Color(0xCC10161C))) {
                for (i in 1..4) { drawLine(Color(0x55FFFFFF), Offset(size.width * i / 5, 0f), Offset(size.width * i / 5, size.height)); drawLine(Color(0x55FFFFFF), Offset(0f, size.height * i / 5), Offset(size.width, size.height * i / 5)) }
                drawCircle(Color(ch.color), 5f, center)
            }
        }
        // ซ้ายล่าง/ขวาล่าง (สลับได้ตาม Layout)
        val moveAlign = if (lefty) Alignment.BottomEnd else Alignment.BottomStart
        val actAlign = if (lefty) Alignment.BottomStart else Alignment.BottomEnd
        Box(Modifier.align(moveAlign).padding(28.dp)) { Joystick((130 * k).dp) { x, y -> gl?.renderer?.moveX = x; gl?.renderer?.moveF = -y } }
        Column(Modifier.align(actAlign).padding(24.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // ปุ่มทดสอบ Auto-Save (เหตุการณ์จริงจะถูกยิงจากระบบภารกิจ/ตู้เสื้อผ้า/ระบบยานพาหนะ)
            Button(onClick = { vm.saves.onEvent(GameEvent.MissionCompleted) }, modifier = Modifier.height((38 * k).dp)) { Text("ภารกิจสำเร็จ", fontSize = 12.sp) }
            OutlinedButton(onClick = { val n = outfits[(outfits.indexOf(save.outfit) + 1).mod(outfits.size)]; vm.saves.onEvent(GameEvent.OutfitChanged(n)) }, modifier = Modifier.height((38 * k).dp)) { Text("เปลี่ยนชุด: ${save.outfit}", fontSize = 12.sp) }
            OutlinedButton(onClick = { vm.saves.onEvent(GameEvent.VehicleExited) }, modifier = Modifier.height((38 * k).dp)) { Text("ลงจากรถ", fontSize = 12.sp) }
            FilledTonalButton(onClick = { if (abilityReady) abilityReady = false }, enabled = abilityReady, modifier = Modifier.height((46 * k).dp)) { Text("★ ${ch.ability}") }
        }
    }
}

@Composable
fun Joystick(size: androidx.compose.ui.unit.Dp, onMove: (Float, Float) -> Unit) {
    var off by remember { mutableStateOf(Offset.Zero) }
    Box(Modifier.size(size).background(Color(0x44FFFFFF), CircleShape).pointerInput(Unit) {
        detectDragGestures(onDragEnd = { off = Offset.Zero; onMove(0f, 0f) }, onDragCancel = { off = Offset.Zero; onMove(0f, 0f) }) { change, _ ->
            val r = this.size.width / 2f
            var v = change.position - Offset(r, r)
            if (v.getDistance() > r) v = v * (r / v.getDistance())
            off = v; onMove(v.x / r, v.y / r)
        }
    }) {
        Box(Modifier.offset { IntOffset(off.x.roundToInt(), off.y.roundToInt()) }.align(Alignment.Center).size(size / 2.6f).background(Color(0xAAFFB300), CircleShape))
    }
}
