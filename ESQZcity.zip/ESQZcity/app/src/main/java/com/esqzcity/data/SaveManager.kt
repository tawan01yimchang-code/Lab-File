package com.esqzcity.data

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.tasks.await

interface CloudSync {
    suspend fun upload(uid: String, json: String)
    suspend fun download(uid: String): String?
}

/** Cloud Save ผ่าน Firestore: saves/{uid} -> { json } */
class FirestoreCloudSync : CloudSync {
    private val col get() = FirebaseFirestore.getInstance().collection("saves")
    override suspend fun upload(uid: String, json: String) { col.document(uid).set(mapOf("json" to json)).await() }
    override suspend fun download(uid: String): String? = col.document(uid).get().await().getString("json")
}

/**
 * Auto-Save: เรียก onEvent() เมื่อ ภารกิจสำเร็จ / เปลี่ยนชุด / ลงจากรถ
 * บันทึกลงเครื่องทันที แล้วอัปโหลดขึ้น Cloud ถ้าล็อกอินอยู่ (แพ้/ชนะตาม updatedAt ล่าสุด)
 */
class SaveManager(ctx: Context, private val cloud: CloudSync) {
    private val prefs = ctx.getSharedPreferences("esqz_save", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(SaveData.fromJson(prefs.getString("save", null)) ?: SaveData())
    val state: StateFlow<SaveData> = _state
    private val _lastSaved = MutableStateFlow(0L)
    val lastSaved: StateFlow<Long> = _lastSaved
    @Volatile var uid: String? = null

    fun update(t: (SaveData) -> SaveData) {
        val n = t(_state.value).copy(updatedAt = System.currentTimeMillis(), hasProgress = true)
        _state.value = n
        prefs.edit().putString("save", n.toJson()).apply()
        _lastSaved.value = n.updatedAt
        uid?.let { u -> scope.launch { runCatching { cloud.upload(u, n.toJson()) } } }
    }

    fun onEvent(e: GameEvent) = when (e) {
        GameEvent.MissionCompleted -> update { it.copy(missionIndex = it.missionIndex + 1, money = it.money + 1500) }
        is GameEvent.OutfitChanged -> update { it.copy(outfit = e.outfit) }
        GameEvent.VehicleExited -> update { it.copy(inVehicle = false) }
    }

    /** เรียกหลังล็อกอิน: ข้อมูลที่ใหม่กว่าชนะ */
    suspend fun sync(userId: String) = withContext(Dispatchers.IO) {
        uid = userId
        val remote = runCatching { SaveData.fromJson(cloud.download(userId)) }.getOrNull()
        val local = _state.value
        if (remote != null && remote.updatedAt > local.updatedAt) {
            _state.value = remote
            prefs.edit().putString("save", remote.toJson()).apply()
        } else if (local.hasProgress) runCatching { cloud.upload(userId, local.toJson()) }
    }

    fun signedOut() { uid = null }
}
