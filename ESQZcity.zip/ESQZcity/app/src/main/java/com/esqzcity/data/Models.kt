package com.esqzcity.data

import org.json.JSONObject

/** ตัวละครหลัก 8 ตัว — ข้อมูลสเปก + คำอธิบายแอสเซ็ตความสมจริงที่ต้องใส่ใน Asset Pipeline */
data class GameCharacter(
    val id: Int, val name: String, val role: String,
    val health: Int, val armor: Int, val stamina: Int,
    val ability: String, val abilityDesc: String,
    val outfit: String, val tattoos: String, val scars: String, val hair: String,
    val color: Long
)

object Roster {
    val all = listOf(
        GameCharacter(0, "Rex Navarro", "Street Racer", 90, 40, 85, "Nitro Drift", "ดริฟต์ + บูสต์ความเร็วรถ 6 วินาที", "แจ็กเก็ตแข่ง หนังสีดำ-ส้ม", "เปลวไฟที่คอ", "แผลเป็นแก้มซ้าย", "ผมสั้นเฟด + ฟิสิกส์ลมปะทะ", 0xFFFF6D00),
        GameCharacter(1, "Mira Volkov", "Sniper", 75, 55, 70, "Eagle Eye", "สโลว์โมชัน + ซูมเล็งแม่นยำ", "เสื้อคลุมยุทธวิธีสีเทา", "ลายหมาป่าที่ต้นแขน", "รอยไหม้ที่มือ", "ผมยาวถักเปีย + Hair Physics", 0xFF90A4AE),
        GameCharacter(2, "Dante Cruz", "Enforcer", 120, 80, 60, "Iron Skin", "ลดดาเมจ 50% เป็นเวลา 8 วินาที", "สูทดำ เสื้อกั๊กกันกระสุน", "ไม้กางเขนที่หน้าอก", "แผลกรีดที่คิ้ว", "ผมหวีเรียบ", 0xFFB71C1C),
        GameCharacter(3, "Jade Lin", "Hacker", 70, 30, 75, "System Breach", "แฮ็กไฟจราจร กล้อง และประตูอัตโนมัติ", "ฮู้ดนีออนเขียว-ฟ้า", "ลายวงจรที่ท้องแขน", "ไม่มี", "ผมบ็อบสีฟ้าเมทัลลิก", 0xFF26C6DA),
        GameCharacter(4, "Ozzy Brooks", "Dock Brawler", 110, 60, 90, "Heavy Hands", "หมัดทำลายสิ่งแวดล้อมได้ (กำแพง/ประตู)", "ชุดช่างท่าเรือ เปื้อนน้ำมัน", "สมอเรือที่ปลายแขน", "แผลเป็นที่มือขวา", "ผมไถข้าง หนวดเคราเต็ม", 0xFFFFB300),
        GameCharacter(5, "Sasha Reed", "Pilot / Smuggler", 80, 35, 80, "Sky Master", "ควบคุมเฮลิคอปเตอร์/เครื่องบินระดับเทพ", "แจ็กเก็ตนักบิน ผ้าพันคอ", "ปีกนกที่ไหปลาร้า", "แผลที่ไหล่", "ผมหางม้า + ฟิสิกส์ลม", 0xFF7E57C2),
        GameCharacter(6, "Kenji Mori", "Fixer", 85, 45, 72, "Silver Tongue", "ลดราคาร้านค้า/ลดระดับ Wanted", "สูทเข้ารูปสีกรมท่า", "ไม่มี", "รอยแผลที่ลำคอ", "ผมเซ็ตเรียบ", 0xFF42A5F5),
        GameCharacter(7, "Luna Okafor", "Street Medic", 95, 50, 78, "Field Surgeon", "ชุบชีวิต/ฮีลตัวเองและเพื่อน NPC", "ชุดพยาบาลสนามดัดแปลง", "ลายดอกไม้ที่ขา", "แผลเป็นที่หัวเข่า", "ผมหยิกธรรมชาติ + Hair Physics", 0xFF66BB6A)
    )
}

data class GameSettings(
    // Graphics
    val preset: String = "High", val fps: Int = 60, val resScale: Float = 1f,
    val shadows: String = "High", val aa: String = "TAA",
    val rayTracing: Boolean = false, val motionBlur: Boolean = false,
    // Audio
    val master: Float = 0.8f, val music: Float = 0.6f, val radio: String = "Neon FM",
    val sfx: Float = 0.8f, val voice: Float = 0.8f, val surround: Boolean = false,
    // Controls
    val layout: String = "Default", val buttonSize: Float = 1f, val sensitivity: Float = 0.5f,
    val steering: String = "Buttons", val gamepad: Boolean = true,
    // Gameplay
    val traffic: Float = 0.5f, val npc: Float = 0.5f, val subtitles: Boolean = true, val miniMap: String = "Round"
) {
    fun withPreset(p: String): GameSettings = when (p) {
        "Low" -> copy(preset = p, fps = 30, resScale = 0.6f, shadows = "Low", aa = "FXAA", rayTracing = false, motionBlur = false)
        "Medium" -> copy(preset = p, fps = 30, resScale = 0.8f, shadows = "Medium", aa = "FXAA", rayTracing = false, motionBlur = false)
        "High" -> copy(preset = p, fps = 60, resScale = 1f, shadows = "High", aa = "TAA", rayTracing = false, motionBlur = false)
        "Ultra" -> copy(preset = p, fps = 60, resScale = 1f, shadows = "Ultra", aa = "TAA", rayTracing = true, motionBlur = true)
        else -> copy(preset = "Extreme", fps = 120, resScale = 1f, shadows = "Ultra", aa = "TAA", rayTracing = true, motionBlur = true)
    }

    fun toJson() = JSONObject().apply {
        put("preset", preset); put("fps", fps); put("resScale", resScale.toDouble()); put("shadows", shadows); put("aa", aa)
        put("rt", rayTracing); put("blur", motionBlur); put("master", master.toDouble()); put("music", music.toDouble())
        put("radio", radio); put("sfx", sfx.toDouble()); put("voice", voice.toDouble()); put("surround", surround)
        put("layout", layout); put("btn", buttonSize.toDouble()); put("sens", sensitivity.toDouble())
        put("steer", steering); put("pad", gamepad); put("traffic", traffic.toDouble()); put("npc", npc.toDouble())
        put("subs", subtitles); put("map", miniMap)
    }.toString()

    companion object {
        fun fromJson(s: String?): GameSettings = runCatching {
            val j = JSONObject(s!!); val d = GameSettings()
            GameSettings(
                j.optString("preset", d.preset), j.optInt("fps", d.fps), j.optDouble("resScale", 1.0).toFloat(),
                j.optString("shadows", d.shadows), j.optString("aa", d.aa), j.optBoolean("rt"), j.optBoolean("blur"),
                j.optDouble("master", .8).toFloat(), j.optDouble("music", .6).toFloat(), j.optString("radio", d.radio),
                j.optDouble("sfx", .8).toFloat(), j.optDouble("voice", .8).toFloat(), j.optBoolean("surround"),
                j.optString("layout", d.layout), j.optDouble("btn", 1.0).toFloat(), j.optDouble("sens", .5).toFloat(),
                j.optString("steer", d.steering), j.optBoolean("pad", true), j.optDouble("traffic", .5).toFloat(),
                j.optDouble("npc", .5).toFloat(), j.optBoolean("subs", true), j.optString("map", d.miniMap)
            )
        }.getOrDefault(GameSettings())
    }
}

/** ข้อมูลเซฟเกม (ซิงก์ขึ้น Cloud) */
data class SaveData(
    val characterId: Int = 0, val missionIndex: Int = 0, val outfit: String = "Default",
    val money: Long = 5000, val x: Float = 0f, val z: Float = 0f,
    val hour: Float = 8f, val weather: String = "Clear", val inVehicle: Boolean = false,
    val updatedAt: Long = 0L, val hasProgress: Boolean = false
) {
    fun toJson() = JSONObject().apply {
        put("c", characterId); put("m", missionIndex); put("o", outfit); put("$", money)
        put("x", x.toDouble()); put("z", z.toDouble()); put("h", hour.toDouble()); put("w", weather)
        put("v", inVehicle); put("t", updatedAt); put("p", hasProgress)
    }.toString()

    companion object {
        fun fromJson(s: String?): SaveData? = runCatching {
            val j = JSONObject(s!!)
            SaveData(j.getInt("c"), j.getInt("m"), j.getString("o"), j.getLong("$"), j.getDouble("x").toFloat(),
                j.getDouble("z").toFloat(), j.getDouble("h").toFloat(), j.getString("w"), j.getBoolean("v"),
                j.getLong("t"), j.optBoolean("p"))
        }.getOrNull()
    }
}

sealed interface GameEvent {
    data object MissionCompleted : GameEvent
    data class OutfitChanged(val outfit: String) : GameEvent
    data object VehicleExited : GameEvent
}
