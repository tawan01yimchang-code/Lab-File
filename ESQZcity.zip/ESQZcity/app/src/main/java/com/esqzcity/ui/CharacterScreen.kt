package com.esqzcity.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.esqzcity.data.Roster

@Composable
fun CharacterScreen(vm: AppViewModel, onBack: () -> Unit) {
    val save by vm.saves.state.collectAsState()
    var sel by remember { mutableIntStateOf(save.characterId) }
    val ch = Roster.all[sel]
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = onBack) { Text("← Back") }
            Text("Character Selection", fontSize = 22.sp, fontWeight = FontWeight.Black)
            Button(onClick = { vm.selectCharacter(sel); onBack() }) { Text("Select") }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 10.dp)) {
            items(Roster.all) { c ->
                Card(onClick = { sel = c.id }, shape = RoundedCornerShape(12.dp),
                    border = if (c.id == sel) BorderStroke(2.dp, Color(c.color)) else null, modifier = Modifier.width(110.dp)) {
                    Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(54.dp), contentAlignment = Alignment.Center) { Surface(shape = RoundedCornerShape(27.dp), color = Color(c.color), modifier = Modifier.fillMaxSize()) {} }
                        Text(c.name.substringBefore(' '), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(c.role, fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Card(Modifier.weight(1f)) { Column(Modifier.padding(14.dp)) {
                Text(ch.name, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(ch.role, color = Color(ch.color))
                Spacer(Modifier.height(8.dp))
                StatBar("Health", ch.health, 120, Color(0xFFE53935)); StatBar("Armor", ch.armor, 100, Color(0xFF42A5F5)); StatBar("Stamina", ch.stamina, 100, Color(0xFF66BB6A))
                Spacer(Modifier.height(6.dp))
                Text("★ Special: ${ch.ability}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(ch.abilityDesc, fontSize = 12.sp)
            } }
            Card(Modifier.weight(1f)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Look & Realism", fontWeight = FontWeight.Bold)
                Text("ชุด: ${ch.outfit}", fontSize = 12.sp); Text("รอยสัก: ${ch.tattoos}", fontSize = 12.sp)
                Text("รอยแผล: ${ch.scars}", fontSize = 12.sp); Text("ผม: ${ch.hair}", fontSize = 12.sp)
                Text("โมเดล: PBR textures + skin shader (SSS) + motion-captured animation (ใส่แอสเซ็ตจริงตาม docs)", fontSize = 11.sp, color = Color.Gray)
            } }
        }
    }
}
