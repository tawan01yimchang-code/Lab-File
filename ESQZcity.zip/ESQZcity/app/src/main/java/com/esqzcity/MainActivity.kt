package com.esqzcity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.esqzcity.ui.*

enum class Screen { Title, Characters, Settings, Game }

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFFFB300), secondary = Color(0xFF26C6DA), background = Color(0xFF0B0F14), surface = Color(0xFF141A22))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var screen by remember { mutableStateOf(Screen.Title) }
                    BackHandler(screen != Screen.Title) { screen = Screen.Title }
                    when (screen) {
                        Screen.Title -> TitleScreen(vm, this@MainActivity, go = { screen = it })
                        Screen.Characters -> CharacterScreen(vm, onBack = { screen = Screen.Title })
                        Screen.Settings -> SettingsScreen(vm, onBack = { screen = Screen.Title })
                        Screen.Game -> GameScreen(vm, onExit = { screen = Screen.Title })
                    }
                }
            }
        }
    }
}
