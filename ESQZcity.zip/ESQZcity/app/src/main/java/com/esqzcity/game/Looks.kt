package com.esqzcity.game

/** รูปลักษณ์ตัวละครสำหรับโมเดล procedural (ผิว/ผม/ชุด/รอยสัก/แผลเป็น/ผมที่มีฟิสิกส์) */
class Look(val skin: FloatArray, val hair: FloatArray, val top: FloatArray, val bottom: FloatArray,
           val tattoo: FloatArray?, val scar: Boolean, val tail: Boolean)

object Looks {
    private fun c(r: Float, g: Float, b: Float) = floatArrayOf(r, g, b)
    val outfits = listOf("Default", "Street", "Formal", "Tactical")
    val all = listOf(
        Look(c(.72f, .52f, .40f), c(.10f, .08f, .07f), c(.90f, .35f, .05f), c(.12f, .12f, .14f), c(1f, .4f, 0f), true, false),   // Rex
        Look(c(.90f, .74f, .65f), c(.78f, .70f, .50f), c(.40f, .45f, .48f), c(.20f, .22f, .25f), c(.2f, .2f, .25f), false, true), // Mira
        Look(c(.45f, .30f, .22f), c(.05f, .05f, .05f), c(.07f, .07f, .08f), c(.07f, .07f, .08f), null, true, false),              // Dante
        Look(c(.85f, .70f, .58f), c(.20f, .55f, .90f), c(.10f, .90f, .70f), c(.10f, .12f, .20f), c(.2f, .9f, .9f), false, false), // Jade
        Look(c(.80f, .60f, .50f), c(.35f, .20f, .10f), c(.90f, .65f, .10f), c(.20f, .25f, .40f), c(.2f, .3f, .5f), true, false),  // Ozzy
        Look(c(.80f, .60f, .48f), c(.45f, .25f, .12f), c(.45f, .30f, .70f), c(.20f, .15f, .10f), c(.5f, .3f, .7f), false, true), // Sasha
        Look(c(.85f, .70f, .55f), c(.05f, .05f, .06f), c(.10f, .20f, .45f), c(.08f, .12f, .25f), null, true, false),              // Kenji
        Look(c(.38f, .25f, .18f), c(.06f, .05f, .05f), c(.35f, .75f, .40f), c(.90f, .90f, .92f), c(.8f, .4f, .6f), false, true)  // Luna
    )
    private val streetT = c(.22f, .22f, .25f); private val streetB = c(.15f, .25f, .50f)
    private val formalT = c(.07f, .07f, .09f); private val formalB = c(.09f, .09f, .11f)
    private val tactT = c(.25f, .30f, .20f); private val tactB = c(.20f, .24f, .16f)
    fun top(l: Look, o: Int) = when (o) { 1 -> streetT; 2 -> formalT; 3 -> tactT; else -> l.top }
    fun bottom(l: Look, o: Int) = when (o) { 1 -> streetB; 2 -> formalB; 3 -> tactB; else -> l.bottom }
}
