package com.esqzcity.game

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** วงจรวัน-เวลา 24 ชม. (ค่าเริ่มต้น 1 วันในเกม = 24 นาทีจริง) */
class DayNightCycle(var minutesPerDay: Float = 24f) {
    @Volatile var hour = 8f
    @Volatile var paused = false
    fun update(dt: Float) { if (!paused) hour = (hour + dt * 24f / (minutesPerDay * 60f)) % 24f }
    /** ความสูงดวงอาทิตย์ -1..1 (ติดลบ = กลางคืน) */
    val sunHeight get() = sin(((hour - 6f) / 12f * PI).toFloat())
    val dayFactor get() = (sunHeight * 3f).coerceIn(0f, 1f)
    val nightFactor get() = 1f - dayFactor
    /** แสงส้มช่วงเช้า/เย็น */
    val duskFactor get() = (1f - abs(sunHeight) * 4f).coerceIn(0f, 1f)
    val label get() = "%02d:%02d".format(hour.toInt(), ((hour % 1f) * 60).toInt())
}

enum class Weather { Clear, Rain, Fog }

class WeatherSystem {
    @Volatile var type = Weather.Clear
    fun set(w: Weather) { type = w }
    fun next() { type = Weather.entries[(type.ordinal + 1) % Weather.entries.size] }
    val fogDensity get() = when (type) { Weather.Clear -> 0.0018f; Weather.Rain -> 0.0045f; Weather.Fog -> 0.014f }
    val darkness get() = when (type) { Weather.Clear -> 0f; Weather.Rain -> 0.35f; Weather.Fog -> 0.2f }
    val raining get() = type == Weather.Rain
}

/** สร้างผังเมืองแบบ procedural: ใจกลางตึกระฟ้า / ย่านการค้า / สลัม / ท่าเรือ / ชานเมือง / ทางด่วนยกระดับ */
data class Bld(val x: Float, val z: Float, val w: Float, val d: Float, val h: Float, val r: Float, val g: Float, val b: Float)

object CityGen {
    const val PITCH = 22f
    const val N = 11

    fun generate(): List<Bld> {
        val rnd = java.util.Random(42)
        val out = ArrayList<Bld>()
        fun rf(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)
        for (i in -N..N) for (j in -N..N) {
            val cx = i * PITCH; val cz = j * PITCH
            val ring = maxOf(abs(i), abs(j))
            when {
                j <= -11 -> continue                                   // ผืนน้ำ
                j <= -9 -> out += Bld(cx, cz, rf(8f, 12f), rf(4f, 6f), rf(3f, 6f), rf(.3f, .9f), rf(.2f, .5f), rf(.2f, .8f)) // ท่าเรือ: คอนเทนเนอร์
                i >= 6 && j >= 2 -> out += Bld(cx + rf(-3f, 3f), cz + rf(-3f, 3f), rf(5f, 10f), rf(5f, 10f), rf(4f, 10f), rf(.45f, .6f), rf(.25f, .35f), .2f) // สลัม
                ring <= 3 -> { val g = rf(.35f, .6f); out += Bld(cx, cz, rf(9f, 13f), rf(9f, 13f), rf(40f, 140f), g * .8f, g, g * 1.3f) } // ตึกระฟ้า
                ring <= 6 -> out += Bld(cx, cz, rf(10f, 14f), rf(10f, 14f), rf(15f, 45f), rf(.5f, .8f), rf(.4f, .6f), rf(.3f, .5f))  // ย่านการค้า
                else -> out += Bld(cx, cz, rf(7f, 10f), rf(7f, 10f), rf(4f, 9f), rf(.7f, .9f), rf(.7f, .85f), rf(.6f, .8f))          // ชานเมือง
            }
        }
        // ทางด่วนยกระดับ + เสา
        val ez = 3 * PITCH + PITCH / 2
        out += Bld(0f, ez, 560f, 8f, 1.2f, .25f, .25f, .27f)
        for (k in -6..6) out += Bld(k * 40f, ez, 2f, 2f, 13f, .3f, .3f, .3f)
        return out
    }
    private fun abs(i: Int) = if (i < 0) -i else i
}
