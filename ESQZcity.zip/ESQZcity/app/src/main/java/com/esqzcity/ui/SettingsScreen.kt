package com.esqzcity.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Graphics", "Audio", "Controls", "Gameplay")
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("← Back") }
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(60.dp))
        }
        TabRow(selectedTabIndex = tab) { tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) } }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
            when (tab) {
                0 -> {
                    ChoiceRow("Preset", listOf("Low", "Medium", "High", "Ultra", "Extreme"), s.preset) { p -> vm.updateSettings { it.withPreset(p) } }
                    ChoiceRow("Frame Rate", listOf("30 FPS", "60 FPS", "120 FPS"), "${s.fps} FPS") { v -> vm.updateSettings { it.copy(fps = v.substringBefore(' ').toInt()) } }
                    SliderRow("Resolution Scaling", s.resScale, 0.5f..1f) { v -> vm.updateSettings { it.copy(resScale = v) } }
                    ChoiceRow("Shadows Quality", listOf("Low", "Medium", "High", "Ultra"), s.shadows) { v -> vm.updateSettings { it.copy(shadows = v) } }
                    ChoiceRow("Anti-Aliasing", listOf("Off", "FXAA", "TAA"), s.aa) { v -> vm.updateSettings { it.copy(aa = v) } }
                    SwitchRow("Ray Tracing (เงาสะท้อนน้ำ/กระจกตึก)", s.rayTracing) { v -> vm.updateSettings { it.copy(rayTracing = v) } }
                    SwitchRow("Motion Blur", s.motionBlur) { v -> vm.updateSettings { it.copy(motionBlur = v) } }
                }
                1 -> {
                    SliderRow("Master Volume", s.master) { v -> vm.updateSettings { it.copy(master = v) } }
                    SliderRow("Music", s.music) { v -> vm.updateSettings { it.copy(music = v) } }
                    ChoiceRow("Radio Station", listOf("Neon FM", "Street Beats 99", "Chill Harbor", "Rock City", "Off"), s.radio) { v -> vm.updateSettings { it.copy(radio = v) } }
                    SliderRow("SFX", s.sfx) { v -> vm.updateSettings { it.copy(sfx = v) } }
                    SliderRow("Dialogue Voice", s.voice) { v -> vm.updateSettings { it.copy(voice = v) } }
                    SwitchRow("3D Surround Sound", s.surround) { v -> vm.updateSettings { it.copy(surround = v) } }
                }
                2 -> {
                    ChoiceRow("Touch Layout", listOf("Default", "Lefty", "Compact"), s.layout) { v -> vm.updateSettings { it.copy(layout = v) } }
                    SliderRow("Button Size", s.buttonSize, 0.7f..1.4f, { "x%.1f".format(it) }) { v -> vm.updateSettings { it.copy(buttonSize = v) } }
                    SliderRow("Sensitivity", s.sensitivity) { v -> vm.updateSettings { it.copy(sensitivity = v) } }
                    ChoiceRow("Steering Mode", listOf("Tilt", "Buttons", "Wheel"), s.steering) { v -> vm.updateSettings { it.copy(steering = v) } }
                    SwitchRow("Controller / Gamepad Support", s.gamepad) { v -> vm.updateSettings { it.copy(gamepad = v) } }
                }
                else -> {
                    SliderRow("Traffic Density (รถบนถนน)", s.traffic) { v -> vm.updateSettings { it.copy(traffic = v) } }
                    SliderRow("NPC Density (คนเดินถนน)", s.npc) { v -> vm.updateSettings { it.copy(npc = v) } }
                    SwitchRow("Subtitles", s.subtitles) { v -> vm.updateSettings { it.copy(subtitles = v) } }
                    ChoiceRow("Mini-Map Style", listOf("Round", "Square", "Off"), s.miniMap) { v -> vm.updateSettings { it.copy(miniMap = v) } }
                }
            }
        }
    }
}
