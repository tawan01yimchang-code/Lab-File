package com.esqzcity.ui

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.esqzcity.Screen
import com.esqzcity.data.Roster

@Composable
fun TitleScreen(vm: AppViewModel, activity: Activity, go: (Screen) -> Unit) {
    val user by vm.auth.userName.collectAsState()
    val save by vm.saves.state.collectAsState()
    val msg by vm.signInMessage.collectAsState()
    val ch = Roster.all[save.characterId.coerceIn(0, 7)]
    Box(Modifier.fillMaxSize()) {
        GameSurface(vm, demo = true, modifier = Modifier.fillMaxSize())          // เมือง 3D แบบไดนามิก (กล้องโคจร + วัน/คืน)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xE60B0F14), Color(0x330B0F14)))))
        Row(Modifier.fillMaxSize().padding(28.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ES QZcity", fontSize = 44.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                Text("OPEN WORLD • ACTION • ADVENTURE", fontSize = 12.sp, letterSpacing = 3.sp)
                Spacer(Modifier.height(10.dp))
                MenuButton("Start Game") { vm.newGame(); go(Screen.Game) }
                MenuButton("Load Game", enabled = save.hasProgress) { vm.loadGame(); go(Screen.Game) }
                MenuButton("Character Selection") { go(Screen.Characters) }
                MenuButton("Settings") { go(Screen.Settings) }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxHeight()) {
                // Google Sign-In / Cloud Sync
                Column(horizontalAlignment = Alignment.End) {
                    if (user == null) OutlinedButton(onClick = { vm.signIn(activity) }) { Text("Sign in with Google") }
                    else { Text("☁ $user", fontSize = 12.sp); TextButton(onClick = { vm.signOut() }) { Text("Sign out") } }
                    Text(msg ?: if (user == null) "ยังไม่ได้ซิงก์ Cloud" else "Cloud Sync: เปิด", fontSize = 11.sp)
                }
                // การ์ดตัวละคร
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xCC141A22)), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp).width(220.dp)) {
                        Box(Modifier.height(6.dp).fillMaxWidth().clip(RoundedCornerShape(3.dp)).background(Color(ch.color)))
                        Spacer(Modifier.height(8.dp))
                        Text(ch.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(ch.role, fontSize = 12.sp, color = Color(ch.color))
                        Spacer(Modifier.height(6.dp))
                        StatBar("Health", ch.health, 120, Color(0xFFE53935)); StatBar("Armor", ch.armor, 100, Color(0xFF42A5F5)); StatBar("Stamina", ch.stamina, 100, Color(0xFF66BB6A))
                        Text("★ ${ch.ability}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.width(240.dp).height(46.dp), shape = RoundedCornerShape(10.dp)) { Text(text, fontWeight = FontWeight.Bold) }
}
