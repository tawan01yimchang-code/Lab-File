package com.esqzcity.ui

import android.app.Activity
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.esqzcity.auth.AuthManager
import com.esqzcity.data.*
import com.esqzcity.game.DayNightCycle
import com.esqzcity.game.Weather
import com.esqzcity.game.WeatherSystem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("esqz_settings", Context.MODE_PRIVATE)
    val auth = AuthManager(app)
    val saves = SaveManager(app, FirestoreCloudSync())
    val clock = DayNightCycle()
    val weather = WeatherSystem()

    private val _settings = MutableStateFlow(GameSettings.fromJson(prefs.getString("s", null)))
    val settings: StateFlow<GameSettings> = _settings
    val signInMessage = MutableStateFlow<String?>(null)

    fun updateSettings(f: (GameSettings) -> GameSettings) {
        _settings.value = f(_settings.value)
        prefs.edit().putString("s", _settings.value.toJson()).apply()
    }

    fun signIn(activity: Activity) = viewModelScope.launch {
        auth.signIn(activity)
            .onSuccess { saves.sync(it); signInMessage.value = "ซิงก์ข้อมูลกับ Cloud แล้ว" }
            .onFailure { signInMessage.value = "ล็อกอินไม่สำเร็จ: ตรวจสอบ google-services.json และ web_client_id" }
    }

    fun signOut() { auth.signOut(); saves.signedOut() }
    fun selectCharacter(id: Int) = saves.update { it.copy(characterId = id) }
    fun newGame() { saves.update { SaveData(characterId = it.characterId) }; clock.hour = 8f; weather.set(Weather.Clear) }
    fun loadGame() { val s = saves.state.value; clock.hour = s.hour; weather.set(runCatching { Weather.valueOf(s.weather) }.getOrDefault(Weather.Clear)) }
}

