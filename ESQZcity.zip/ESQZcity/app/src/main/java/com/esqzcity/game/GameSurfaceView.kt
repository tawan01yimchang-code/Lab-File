package com.esqzcity.game

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import com.esqzcity.data.GameSettings

class GameSurfaceView(ctx: Context, demo: Boolean, clock: DayNightCycle, weather: WeatherSystem) : GLSurfaceView(ctx) {
    val renderer = CityRenderer(demo, clock, weather)
    private var lx = 0f; private var ly = 0f
    private var lastScale = -1f

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 24, 0)
        setRenderer(renderer)
        addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ -> if (lastScale < 0f && r - l > 0) applySettings(renderer.settings) }
    }

    /** นำค่าตั้งค่ากราฟิกมาใช้: Resolution Scaling ผ่าน fixed surface size */
    fun applySettings(s: GameSettings) {
        renderer.settings = s
        if (width > 0 && s.resScale != lastScale) {
            lastScale = s.resScale
            holder.setFixedSize((width * s.resScale).toInt().coerceAtLeast(320), (height * s.resScale).toInt().coerceAtLeast(180))
        }
    }

    /** ลากนิ้วบนจอ = หมุนกล้อง (ความไวตาม Sensitivity) */
    var sensitivity = 0.5f
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_MOVE -> {
                val k = 0.002f + sensitivity * 0.008f
                renderer.yaw -= (e.x - lx) * k; renderer.pitch = (renderer.pitch + (e.y - ly) * k).coerceIn(0.1f, 1.3f)
                lx = e.x; ly = e.y
            }
        }
        return true
    }
}
