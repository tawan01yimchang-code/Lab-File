package com.esqzcity.auth

import android.app.Activity
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.esqzcity.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.tasks.await

class AuthManager(ctx: Context) {
    private val _user = MutableStateFlow<String?>(null)
    val userName: StateFlow<String?> = _user
    var uid: String? = null; private set

    init {
        // ปลอดภัยถ้ายังไม่ได้ตั้งค่า Firebase (ไม่มี google-services.json)
        runCatching { FirebaseAuth.getInstance().currentUser }.getOrNull()?.let { uid = it.uid; _user.value = it.displayName ?: it.email }
    }

    suspend fun signIn(activity: Activity): Result<String> = runCatching {
        val option = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(activity.getString(R.string.web_client_id))
            .build()
        val res = CredentialManager.create(activity)
            .getCredential(activity, GetCredentialRequest.Builder().addCredentialOption(option).build())
        val google = GoogleIdTokenCredential.createFrom(res.credential.data)
        val r = FirebaseAuth.getInstance().signInWithCredential(GoogleAuthProvider.getCredential(google.idToken, null)).await()
        uid = r.user!!.uid
        _user.value = google.displayName ?: google.id
        uid!!
    }

    fun signOut() { runCatching { FirebaseAuth.getInstance().signOut() }; uid = null; _user.value = null }
}
