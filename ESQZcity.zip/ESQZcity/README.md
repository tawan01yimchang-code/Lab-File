# ES QZcity (Android, Kotlin + Compose + OpenGL ES 3.0)

1. เปิดโฟลเดอร์นี้ด้วย Android Studio (Koala+ / JDK 17) → Sync → Run บนมือถือ/แท็บเล็ต (เล่นแนวนอน)
2. (ทางเลือก) ตั้งค่า Google Sign-In + Cloud Save ตาม `docs/ARCHITECTURE.md` ข้อ 9
3. เปิด `docs/ui_mockup.html` ในเบราว์เซอร์เพื่อดู UI Mockup
4. แผนสถาปัตยกรรมทั้งหมด: `docs/ARCHITECTURE.md`

สถานะ: v0.2 — เรนเดอร์ยกระดับ (ท้องฟ้า/เมฆ, เงา, แสง PBR-lite, กระจกสะท้อน, ถนนเปียก, ตัวละครมีข้อต่อ+ผมฟิสิกส์) บนโครง M1 — เมนู, เลือกตัวละคร 8 ตัว, ตั้งค่าครบทุกหมวด, Auto-Save + Cloud Sync, เมือง 3D แบบบล็อกพร้อมวัน-คืน/สภาพอากาศ/ท่าเรือ/สลัม/ทางด่วนยกระดับ
